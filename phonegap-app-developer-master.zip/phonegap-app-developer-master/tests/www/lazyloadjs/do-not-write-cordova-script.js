_doNotWriteCordovaScript = true;
