#!/usr/bin/env bash
echo "$ npm test"
npm test
